import React, { useState, useEffect } from 'react';

function App() {
  const [count, setCount] = useState(0);
  const [user, setUser] = useState(null);

  useEffect(() => {
    fetch('https://randomuser.me/api/')
      .then((res) => res.json())
      .then((data) => setUser(data.results[0]));
  }, []);

  return (
    <div style={{ textAlign: 'center', marginTop: 50 }}>
      <h1>Contador: {count}</h1>
      <button onClick={() => setCount(count + 1)}>+</button>
      <button onClick={() => setCount(count - 1)}>-</button>
      <button onClick={() => setCount(0)}>Reset</button>

      <div style={{ marginTop: 40 }}>
        {user ? (
          <div>
            <h2>{user.name.first} {user.name.last}</h2>
            <img src={user.picture.medium} alt="User" />
          </div>
        ) : (
          <p>Cargando usuario...</p>
        )}
      </div>
    </div>
  );
}

export default App;
