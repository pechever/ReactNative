import React, { useState } from 'react';
import ThemeContext from './ThemeContext';
import ThemedComponent from './ThemedComponent';

function App() {
  const [theme, setTheme] = useState('light');

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <div style={{ padding: 20 }}>
        <h1>Gestión de Tema</h1>
        <button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
          Cambiar Tema
        </button>
        <ThemedComponent />
      </div>
    </ThemeContext.Provider>
  );
}

export default App;
